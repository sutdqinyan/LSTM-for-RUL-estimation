clc; clear; close all

load  ('FD0001.mat');   %% Battery 5

Traindata = trainFD001;
Testdata = testFD001;
Truth_data = RULFD001;
End_Life = 120;

%% Remove uncessary variables of training data
Traindata(:, 24) = []; Traindata(:, 23)  = []; Traindata(:, 21) = []; 
Traindata(:, 15) = []; Traindata(:, 11)  = []; Traindata(:, 10) = []; 
Traindata(:, 6)  = []; Traindata(:, 3:5) = []; 
TrainEngine_ID = unique(Traindata(:, 1));
TrainEngineCellData = cell(1, max(TrainEngine_ID));

for ID = 1 : max(TrainEngine_ID)
    for l = 1: size(Traindata, 1)
        if ID == Traindata(l, 1)
           TrainEngineCellData{ID} = [TrainEngineCellData{ID}; Traindata(l, :)];
        end
    end
    TrainEngineCellData{ID}(:, 1:2) = [];
end
Train_Normaldatacell = cell(1, max(TrainEngine_ID)); 
Train_NormalData = [];

for ID = 1 : max(TrainEngine_ID)
    Train_Normaldatacell{ID} = TrainEngineCellData{ID}(1:end-End_Life, :);
    Train_NormalData = [Train_NormalData; Train_Normaldatacell{ID}];
end
[Train_NormalData, meanX, stdX] = autoscale_new(Train_NormalData);

for ID = 1 : max(TrainEngine_ID)
    Temporarydata = [];
    TrainEngineCellData{ID} = autoscale_new(TrainEngineCellData{ID}(:, :), meanX, stdX);
end
Xtrain = [];
for ID = 1 : max(TrainEngine_ID)
    xtrain = [];
    Engine_ID = ID * ones(size(TrainEngineCellData{ID}, 1), 1);
    xtrain = TrainEngineCellData{ID};
    CycleID = 1 : size(xtrain, 1);
    xtrain = [Engine_ID CycleID' xtrain];
    Xtrain = [Xtrain; xtrain];
end

%% Remove uncessary variables of testing data
Testdata(:, 24) = []; Testdata(:, 23)  = []; Testdata(:, 21) = [];
Testdata(:, 15) = []; Testdata(:, 11)  = []; Testdata(:, 10) = [];
Testdata(:, 6)  = []; Testdata(:, 3:5) = [];
TestEngine_ID = unique(Testdata(:, 1));
TestEngineCellData = cell(1, max(TestEngine_ID));
for ID = 1 : max(TestEngine_ID)
    for l = 1: size(Testdata, 1)
        if ID == Testdata(l, 1)
           TestEngineCellData{ID} = [TestEngineCellData{ID}; Testdata(l, :)];
        end
    end
    TestEngineCellData{ID}(:, 1:2) = [];
end
NormalizedTestCell = []; 
Xtest = [];

for ID = 1 : max(TestEngine_ID)
    xtest = [];
    TestEngineCellData{ID} = autoscale_new(TestEngineCellData{ID}, meanX, stdX);    
    Engine_ID = ID * ones(size(TestEngineCellData{ID}, 1), 1);
    xtest = TestEngineCellData{ID};
    CycleID = 1 : size(xtest, 1);
    xtest = [Engine_ID CycleID' xtest];
    Xtest = [Xtest; xtest];
end
dlmwrite('FD0001_train.txt', Xtrain, 'delimiter',' ')
dlmwrite('FD0001_test.txt', Xtest, 'delimiter',' ')